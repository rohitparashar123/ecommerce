<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account Registration</title>
</head>
<body>
    <p>
        Dear {{$name}},<br>
        Your account has been created successfully. <br>
        Your account information has given below <br>
        Email : {{$email}} <br>
        Password : **** (at the time of registration you set) <br>
        Regards, <br>
        Wayshop Team
 
    </p>
</body>
</html>