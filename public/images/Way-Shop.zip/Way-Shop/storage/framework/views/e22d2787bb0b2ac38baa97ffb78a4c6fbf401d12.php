<?php $__env->startSection('content'); ?>

<div class="contact-box-main">

    <div class="container">

        <div class="row">
            <div class="col-lg-6 col-sm-12">
                <div class="contact-form-right">
                    <h2>Billing Address</h2>
                    
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->name); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->address); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->city); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->state); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->country); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e($userDetails->pincode); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                  <?php echo e($userDetails->mobile); ?>

                                </div>
                            </div>
                            
                            
                        </div>
                   
                </div>
            </div>
            <div class="col-lg-6 col-sm-12">
                <div class="contact-form-right">
                    <h2>Shipping Details</h2>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->name); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->address); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->city); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->state); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->country); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->pincode); ?>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e($shippingDetails->mobile); ?>

                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        
        </div>

    </div>

</div>

<!-- Start Cart  -->
<div class="cart-box-main">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-12">
                <div class="table-main table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Images</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $total_amount = 0; ?>
                            <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="thumbnail-img">
                                    <a href="#">
                                <img class="img-fluid" src="<?php echo e(asset('/uploads/products/'.$cart->image)); ?>" alt="" />
                            </a>
                                </td>
                                <td class="name-pr">
                                        
									<?php echo e($cart->product_name); ?>

                                    <p><?php echo e($cart->product_code); ?> | <?php echo e($cart->size); ?></p>
                                    </td>
                                    <td class="price-pr">
                                        <p>PKR <?php echo e($cart->price); ?></p>
                                    </td>
                                <td class="quantity-box">
                                    <?php echo e($cart->quantity); ?>

                                </td>
                                <td class="total-pr">
                                    <p>PKR <?php echo e($cart->price*$cart->quantity); ?></p>
                                    </td>
                                
                            </tr>
                            <?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <div class="order-box">
                    <h3>Your Total</h3>
                    <div class="d-flex">
                        <h4>Cart Sub Total</h4>
                        <div class="ml-auto font-weight-bold"> PKR  <?php echo e($total_amount); ?> </div>
                    </div>
                    <div class="d-flex">
                        <h4>Shipping Cost (+)</h4>
                        <div class="ml-auto font-weight-bold"> PkR 0 </div>
                    </div>
                    <hr class="my-1">
                    <div class="d-flex">
                        <h4>Coupon Discount (-)</h4>
                        <div class="ml-auto font-weight-bold"> 
                            <?php if(!empty(Session::get('CouponAmount'))): ?>
                            PKR <?php echo e(Session::get('CouponAmount')); ?>

                            <?php else: ?>
                            PKR 0
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <hr>
                    <div class="d-flex gr-total">
                        <h5>Grand Total</h5>
                        <div class="ml-auto h5"> PKR <?php echo e($grand_total = $total_amount - Session::get('CouponAmount')); ?> </div>
                    </div>
                    <hr> </div> 
            </div>
            
        </div>

        <form name="paymentForm" id="paymentForm" action="<?php echo e(url('/place-order')); ?>" method="post"> <?php echo e(csrf_field()); ?>

           <input type="hidden" value="<?php echo e($grand_total); ?>" name="grand_total">
            <hr class="mb-4">
            <div class="title-left">
                <h3>Payments</h3>
            </div>
            <div class="d-block my-3">
                <div class="custom-control custom-radio">
                    <input id="credit" name="payment_method" value="cod"  type="radio" class="custom-control-input cod">
                    <label class="custom-control-label" for="credit">Cash On Delivery</label>
                </div>
                <div class="custom-control custom-radio">
                    <input id="debit" name="payment_method" value="paypal" type="radio" class="custom-control-input stripe" >
                    <label class="custom-control-label" for="debit">Stripe</label>
                </div>
                <div class="col-12 d-flex shopping-box">
                    <button  type="submit" class="ml-auto btn hvr-hover" onclick="return selectPaymentMethod();" style="color:white;">Place Order</button> 
                </div>
            </div>
        </form>
    </div>
</div>
<!-- End Cart -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wayshop.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/products/order_review.blade.php ENDPATH**/ ?>