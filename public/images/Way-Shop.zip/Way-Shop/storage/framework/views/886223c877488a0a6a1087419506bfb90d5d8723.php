         <!-- =============================================== -->
         <!-- Left side column. contains the sidebar -->
         <aside class="main-sidebar">
                <!-- sidebar -->
                <div class="sidebar">
                   <!-- sidebar menu -->
                   <ul class="sidebar-menu">
                      <li class="active">
                         <a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fa fa-tachometer"></i><span>Dashboard</span>
                         <span class="pull-right-container">
                         </span>
                         </a>
                      </li>
                      <li class="">
                        <a href="<?php echo e(url('/admin/banners')); ?>"><i class="fa fa-image"></i><span>Banners</span>
                        <span class="pull-right-container">
                        </span>
                        </a>
                     </li>
                      <li class="treeview">
                        <a href="#">
                        <i class="fa fa-list"></i><span>Categories</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                        </a>
                        <ul class="treeview-menu">
                           <li><a href="<?php echo e(url('admin/add-category')); ?>">Add Category</a></li>
                        <li><a href="<?php echo e(url('admin/view-categories')); ?>">View Categories</a></li>
                        </ul>
                     </li>
                      <li class="treeview">
                         <a href="#">
                         <i class="fa fa-product-hunt"></i><span>Products</span>
                         <span class="pull-right-container">
                         <i class="fa fa-angle-left pull-right"></i>
                         </span>
                         </a>
                         <ul class="treeview-menu">
                            <li><a href="<?php echo e(url('admin/add-product')); ?>">Add Product</a></li>
                         <li><a href="<?php echo e(url('admin/view-products')); ?>">View Products</a></li>
                         </ul>
                      </li>
                      <li class="treeview">
                        <a href="#">
                        <i class="fa fa-gift"></i><span>Coupons</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                        </a>
                        <ul class="treeview-menu">
                           <li><a href="<?php echo e(url('admin/add-coupon')); ?>">Add Coupon</a></li>
                        <li><a href="<?php echo e(url('admin/view-coupons')); ?>">View Coupons</a></li>
                        </ul>
                     </li> 
                     <li class="treeview">
                        <a href="<?php echo e(url('admin/orders')); ?>">
                        <i class="pe-7s-cart"></i><span>Orders</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                        </a>
                        
                     </li> 
                     <li class="treeview">
                        <a href="<?php echo e(url('admin/customers')); ?>">
                        <i class="fa fa-users"></i><span>Customers</span>
                        <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                        </span>
                        </a>
                        
                     </li>                      
                      
                   </ul>
                </div>
                <!-- /.sidebar -->
             </aside>
             <!-- =============================================== --><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>