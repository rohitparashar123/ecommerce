<?php $__env->startSection('title','View Products'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
       <div class="header-icon">
          <i class="fa fa-product-hunt"></i>
       </div>
       <div class="header-title">
          <h1>View Products</h1>
          <small>Products List</small>
       </div>
    </section>
    <?php if(Session::has('flash_message_error')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_error')); ?></strong>
    </div>
    <?php endif; ?>
    <?php if(Session::has('flash_message_success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_success')); ?></strong>
    </div>
    <?php endif; ?>

    <div id="message_success" style="display:none;" class="alert alert-sm alert-success">Status Enabled</div>
    <div id="message_error" style="display:none;" class="alert alert-sm alert-danger">Status Disabled</div>
    <!-- Main content -->
    <section class="content">
       <div class="row">
          <div class="col-sm-12">
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>View Products</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="btn-group">
                      <div class="buttonexport" id="buttonlist"> 
                      <a class="btn btn-add" href="<?php echo e(url('admin/add-product')); ?>"> <i class="fa fa-plus"></i> Add Product
                         </a>  
                      </div>
                      
                   </div>
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                         <thead>
                            <tr class="info">
                               <th>ID</th>
                               <th>Product Name</th>
                               <th>Category ID</th>
                               <th>Product Code</th>
                               <th>Product Color</th>
                               <th>Image</th>
                               <th>Price</th>
                               <th>Status</th>
                               <th>Featured Products</th>
                               <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                             <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->category_id); ?></td>
                               <td><?php echo e($product->code); ?></td>
                               <td><?php echo e($product->code); ?></td>
                               <td>
                                   <?php if(!empty($product->image)): ?>
                               <img src="<?php echo e(asset('/uploads/products/'.$product->image)); ?>" alt="" style="width:100px;">
                               </td>
                               <?php endif; ?>
                               <td><?php echo e($product->price); ?></td>
                               <td>
                               <input type="checkbox" class="ProductStatus btn btn-success" rel="<?php echo e($product->id); ?>"
                               data-toggle="toggle" data-on="Enabled" data-of="Disabled" data-onstyle="success" data-offstyle="danger"
                               <?php if($product['status']=="1"): ?> checked <?php endif; ?>>
                               <div id="myElem" style="display:none;" class="alert alert-success">Status Enabled</div>
                               </td>
                               <td>
                                 <input type="checkbox" class="FeaturedStatus btn btn-success" rel="<?php echo e($product->id); ?>"
                                 data-toggle="toggle" data-on="Enabled" data-of="Disabled" data-onstyle="success" data-offstyle="danger"
                                 <?php if($product['status']=="1"): ?> checked <?php endif; ?>>
                                 <div id="myElem" style="display:none;" class="alert alert-success">Status Enabled</div>
                                 </td>
                               <td>
                              <a href="<?php echo e(url('/admin/add-images/'.$product->id)); ?>" class="btn btn-info btn-sm" title="Add Images"><i class="fa fa-image"></i></button>
                              <a href="<?php echo e(url('/admin/add-attributes/'.$product->id)); ?>" class="btn btn-warning btn-sm" title="Add Attributes"><i class="fa fa-list"></i></button>
                               <a href="<?php echo e(url('/admin/edit-product/'.$product->id)); ?>" class="btn btn-add btn-sm" title="Edit Product"><i class="fa fa-pencil"></i></button>
                               <a href="<?php echo e(url('/admin/delete-product/'.$product->id)); ?>" class="btn btn-danger btn-sm" title="Delete Product"><i class="fa fa-trash-o"></i> </button>
                               </td>
                            </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/admin/products/view_products.blade.php ENDPATH**/ ?>