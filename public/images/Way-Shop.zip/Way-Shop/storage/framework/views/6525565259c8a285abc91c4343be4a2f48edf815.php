<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account Activation</title>
</head>
<body>
    <p>
        Dear <?php echo e($name); ?>,<br>
        Please click the link below to activate your account<br>
        <a href="<?php echo e(url('confirm/'.$code)); ?>" target="blank">Activate Account</a> <br>
        Regards, <br>
        Wayshop Team
 
    </p>
</body>
</html><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/email/confirm.blade.php ENDPATH**/ ?>