<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome Email From WayShop</title>
</head>
<body>
    <p>
        Dear <?php echo e($name); ?>,<br>
        Your account has been activated successfully. <br>
        Your account information has given below <br>
        Email : <?php echo e($email); ?> <br>
        Password : **** (at the time of registration you set) <br>
        Regards, <br>
        Wayshop Team
 
    </p>
</body>
</html><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/email/welcome.blade.php ENDPATH**/ ?>