<?php $__env->startSection('content'); ?>
        <div class="cart-box-main">
        <div class="container">
            <h1 align="center">Thanks For Purchasing With Us!</h1> <br><br>
            <div class="row">
                <div class="col-lg-12">
                    <div align="center">
                        <h2>YOUR COD ORDER HAS BEEN PLACED</h2>
                        <p>Your Order Number is <?php echo e(Session::get('order_id')); ?> and total payable about is PKR <?php echo e(Session::get('grand_total')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php

Session::forget('order_id');
Session::forget('grand_total');

?>
<?php echo $__env->make('wayshop.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/orders/thanks.blade.php ENDPATH**/ ?>