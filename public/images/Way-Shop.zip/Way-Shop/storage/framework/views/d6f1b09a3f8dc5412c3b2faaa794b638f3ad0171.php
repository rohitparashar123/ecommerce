<?php $__env->startSection('content'); ?>

<div class="contact-box-main">

    <div class="container">
        <?php if(Session::has('flash_message_error')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_error')); ?></strong>
    </div>
    <?php endif; ?>
    <?php if(Session::has('flash_message_success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_success')); ?></strong>
    </div>
    <?php endif; ?>
    <form name="checkoutFrom" id="checkoutFrom" action="<?php echo e(url('/checkout')); ?>" method="post"> <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-lg-6 col-sm-12">
                <div class="contact-form-right">
                    <h2>Bill To</h2>
                    
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->name)): ?> value="<?php echo e($userDetails->name); ?>" <?php endif; ?> name="billing_name" id="billing_name" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->address)): ?> value="<?php echo e($userDetails->address); ?>" <?php endif; ?>  name="billing_address" id="billing_address" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->city)): ?> value="<?php echo e($userDetails->city); ?>" <?php endif; ?> name="billing_city" id="billing_city" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->state)): ?> value="<?php echo e($userDetails->state); ?>" <?php endif; ?> name="billing_state" id="billing_state" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select name="billing_country" id="billing_country" class="form-control">
                                        <option value="1">Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->country_name); ?>"  <?php if(!empty($userDetails->country) && $country->country_name == $userDetails->country): ?> selected <?php endif; ?>><?php echo e($country->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->pincode)): ?> value="<?php echo e($userDetails->pincode); ?>" <?php endif; ?> name="billing_pincode" id="billing_pincode" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" class="form-control"  <?php if(!empty($userDetails->mobile)): ?> value="<?php echo e($userDetails->mobile); ?>" <?php endif; ?> name="billing_mobile" id="billing_mobile" required data-error="Please enter your name">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            
                             <div class="col-md-12">
                                <div class="form-group" style="margin-left:30px;">
                                    <input  type="checkbox" class="form-check-input" id="billtoship">
                                    <label class="form-check-label" for="billtoship">Shipping Address Same As Billing Address</label>
                                </div>
                            </div> 
                        </div>
                   
                </div>
            </div>
            <div class="col-lg-6 col-sm-12">
                <div class="contact-form-right">
                    <h2>Ship To</h2>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->name)): ?> value="<?php echo e($shippingDetails->name); ?>" <?php endif; ?> name="shipping_name" id="shipping_name" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->address)): ?> value="<?php echo e($shippingDetails->address); ?>" <?php endif; ?> name="shipping_address" id="shipping_address" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->city)): ?> value="<?php echo e($shippingDetails->city); ?>" <?php endif; ?> name="shipping_city" id="shipping_city" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->state)): ?> value="<?php echo e($shippingDetails->state); ?>" <?php endif; ?> name="shipping_state" id="shipping_state" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <select name="shipping_country" id="shipping_country" class="form-control">
                                    <option value="">Select Country</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->country_name); ?>"<?php if(!empty($shippingDetails->country) && $country->country_name == $shippingDetails->country): ?> selected <?php endif; ?>>
                                    <?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->pincode)): ?> value="<?php echo e($shippingDetails->pincode); ?>" <?php endif; ?> name="shipping_pincode" id="shipping_pincode" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control"  <?php if(!empty($shippingDetails->mobile)): ?> value="<?php echo e($shippingDetails->mobile); ?>" <?php endif; ?> name="shipping_mobile" id="shipping_mobile" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="submit-button text-center">
                                <button class="btn hvr-hover" type="submit">Checkout</button>
                               
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        
        </div>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wayshop.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/products/checkout.blade.php ENDPATH**/ ?>