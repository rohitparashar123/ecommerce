<?php $__env->startSection('content'); ?>

    <!-- Start Cart  -->
    <div class="cart-box-main">
            <?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-sm alert-danger alert-block" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
               </button>
               <strong><?php echo session('flash_message_error'); ?></strong>
            </div>
            <?php endif; ?>
            
            <?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-sm alert-success alert-block" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
               </button>
               <strong><?php echo session('flash_message_success'); ?></strong>
            </div>
            <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Images</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total_amount = 0; ?>
                                <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="<?php echo e(asset('/uploads/products/'.$cart->image)); ?>" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                        
									<?php echo e($cart->product_name); ?>

                                    <p><?php echo e($cart->product_code); ?> | <?php echo e($cart->size); ?></p>
                                    </td>
                                    <td class="price-pr">
                                        <p>PKR <?php echo e($cart->price); ?></p>
                                    </td>
                                <td class="quantity-box">
                                <a href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/1')); ?>"  style="font-size:25px;">+</a>
                                    <input type="text" size="4" value="<?php echo e($cart->quantity); ?>" min="0" step="1" class="c-input-text qty text">
                                    <?php if($cart->quantity>1): ?>
                                    <a href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/-1')); ?>"  style="font-size:25px;">-</a>
                                   <?php endif; ?>
                                </td>
                                    <td class="total-pr">
                                    <p>PKR <?php echo e($cart->price*$cart->quantity); ?></p>
                                    </td>
                                    <td class="remove-pr">
                                    <a href="<?php echo e(url('/cart/delete-product/'.$cart->id)); ?>">
									<i class="fas fa-times"></i>
								</a>
                                    </td>
                                </tr>
                                <?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row my-5">
                <div class="col-lg-6 col-sm-6">
                    <div class="coupon-box">
                        <form action="<?php echo e(url('/cart/apply-coupon')); ?>" method="post"> <?php echo e(csrf_field()); ?>

                        <div class="input-group input-group-sm">
                            <input class="form-control" placeholder="Enter your coupon code" name="coupon_code" aria-label="Coupon code" type="text">
                            <div class="input-group-append">
                                <button class="btn btn-theme" type="submit">Apply Coupon</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6">
                    <div class="order-box">
                        <h3>Order summary</h3>
                        <?php if(!empty(Session::get('CouponAmount'))): ?>
                        <div class="d-flex">
                            <h4>Sub Total</h4>
                            <div class="ml-auto font-weight-bold"> PKR <?php echo $total_amount; ?> </div>
                        </div>
                        <hr class="my-1">
                        <div class="d-flex">
                            <h4>Coupon Discount</h4>
                            <div class="ml-auto font-weight-bold"> PKR <?php echo Session::get('CouponAmount'); ?> </div>
                        </div>
                        <hr>
                        <div class="d-flex gr-total">
                            <h5>Grand Total</h5>
                            <div class="ml-auto h5"> PKR  <?php echo $total_amount - Session::get('CouponAmount'); ?> </div>
                        </div>
                        <hr>
                        <?php else: ?>
                        <div class="d-flex gr-total">
                            <h5>Grand Total</h5>
                            <div class="ml-auto h5"> PKR  <?php echo $total_amount; ?> </div>
                        </div>
                        <?php endif; ?>
                      
                    </div>
                    <div class="col-12 d-flex shopping-box"><a href="<?php echo e(url('/checkout')); ?>" class="ml-auto btn hvr-hover">Checkout</a>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <!-- End Cart -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wayshop.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/wayshop/products/cart.blade.php ENDPATH**/ ?>