<?php $__env->startSection('title','View Coupons'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
       <div class="header-icon">
          <i class="fa fa-eye"></i>
       </div>
       <div class="header-title">
          <h1>View Coupons</h1>
          <small>Coupons</small>
       </div>
    </section>
    <?php if(Session::has('flash_message_error')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_error')); ?></strong>
    </div>
    <?php endif; ?>
    <?php if(Session::has('flash_message_success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
    <strong><?php echo e(session('flash_message_success')); ?></strong>
    </div>
    <?php endif; ?>

    <div id="message_success" style="display:none;" class="alert alert-sm alert-success">Status Enabled</div>
    <div id="message_error" style="display:none;" class="alert alert-sm alert-danger">Status Disabled</div>
    <!-- Main content -->
    <section class="content">
       <div class="row">
          <div class="col-sm-12">
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>View Coupons</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="btn-group">
                      <div class="buttonexport" id="buttonlist"> 
                      <a class="btn btn-add" href="<?php echo e(url('admin/add-coupon')); ?>"> <i class="fa fa-plus"></i> Add Coupon
                         </a>  
                      </div>
                      
                   </div>
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                         <thead>
                            <tr class="info">
                                <th>Coupon ID</th>
                                <th>Coupon Code</th>
                                <th>Amount</th>
                                <th>Amount Type</th>
                                <th>Expiry Date</th>
                                <th>Created Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($coupon->id); ?></td>
                            <td><?php echo e($coupon->coupon_code); ?></td>
                            <td>
                            <?php echo e($coupon->amount); ?>

                            <?php if($coupon->amount_type == "Percentage"): ?> % <?php else: ?> PKR <?php endif; ?>
                            </td>
                            <td><?php echo e($coupon->amount_type); ?></td>
                            <td><?php echo e($coupon->expiry_date); ?></td>
                            <td><?php echo e($coupon->created_at); ?></td>
                            <td>
                                <input type="checkbox" class="CouponStatus btn btn-success" rel="<?php echo e($coupon->id); ?>" data-toggle="toggle" data-on="Enabled" data-off="Disabled" data-onstyle="success" data-offstyle="danger"
                                <?php if($coupon['status']=="1"): ?> checked <?php endif; ?>>
                                <div id="myElem" style="display:none" class="alert alert-success">Status Enabled</div>
                              </td>
                            <td>
                            <a href="<?php echo e(url('/admin/edit-coupon/'.$coupon->id)); ?>" class="btn btn-add btn-sm"><i class="fa fa-pencil"></i></a>
                            <a  href="<?php echo e(url('/admin/delete-coupon/'.$coupon->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> </a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/admin/coupons/view_coupons.blade.php ENDPATH**/ ?>