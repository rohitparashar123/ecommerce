<?php $__env->startSection('title','Order Details'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
       <div class="header-icon">
          <i class="fa fa-eye"></i>
       </div>
       <div class="header-title">
          <h1>Order <?php echo e($orderDetails->id); ?></h1>
       </div>
    </section>
    <?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-error alert-block">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong><?php echo e(session('flash_message_error')); ?></strong>
            </div>
            <?php endif; ?>
            <?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong><?php echo e(session('flash_message_success')); ?></strong>
            </div>
            <?php endif; ?>

    <div id="message_success" style="display:none;" class="alert alert-sm alert-success">Status Enabled</div>
    <div id="message_error" style="display:none;" class="alert alert-sm alert-danger">Status Disabled</div>
    <!-- Main content -->
    <section class="content">
       <div class="row">
          <div class="col-sm-6">
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>Order Details</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                        
                         <tbody>
                           <tr>
                               <td class="taskDesc"> Order Date</td>
                               <td class="taskStatus"> <?php echo e($orderDetails->created_at->format('Y-m-d')); ?></td>
                           </tr>
                           <tr>
                            <td class="taskDesc"> Order Status</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->order_status); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Order Total</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->grand_total); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Shipping Charges</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->shipping_charges); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Coupon Code</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->coupon_code); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Coupon Amount</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->coupon_amount); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Payment Method</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->payment_method); ?></td>
                        </tr>
                        
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>Billing Address</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                        
                         <tbody>
                           <tr>
                               <td class="taskDesc"> Name</td>
                               <td class="taskStatus"> <?php echo e($orderDetails->name); ?></td>
                           </tr>
                           <tr>
                            <td class="taskDesc"> Address</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->address); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> City</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->city); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> State</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->state); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Country</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->country); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Country Code</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->pincode); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Mobile</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->mobile); ?></td>
                        </tr>
                        
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
             
          </div>
          <div class="col-lg-6">
            <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>Customer Details</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                        
                         <tbody>
                           <tr>
                               <td class="taskDesc"> Customer Name</td>
                               <td class="taskStatus"> <?php echo e($orderDetails->name); ?></td>
                           </tr>
                           <tr>
                            <td class="taskDesc"> Customer Email</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->user_email); ?></td>
                        </tr>
                        
                        
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>Shipping Address update</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <form action="<?php echo e(url('/admin/update-order-status')); ?>" method="post"><?php echo e(csrf_field()); ?>

                    <input type="hidden" name="order_id" value="<?php echo e($orderDetails->id); ?>">
                    <table style="width:100%;">
                        <tr>
                            <td>
                                <select name="order_status" id="order_sstaus" class="form-control">
                                    <option value="New" <?php if($orderDetails->order_status== "New"): ?> selected <?php endif; ?>>
                                        New</option>
                                    <option value="Pending" <?php if($orderDetails->order_status== "Pending"): ?> selected <?php endif; ?>>
                                        Pending</option>
                                    <option value="In Process" <?php if($orderDetails->order_status== "In Process"): ?> selected <?php endif; ?>>
                                        In Process</option>
                                    <option value="Shipped" <?php if($orderDetails->order_status== "Shipped"): ?> selected <?php endif; ?>>
                                        Shipped</option>
                                    <option value="Delivered" <?php if($orderDetails->order_status== "Delivered"): ?> selected <?php endif; ?>>
                                        Delivered</option>
                                    <option value="Cancelled" <?php if($orderDetails->order_status== "Cancelled"): ?> selected <?php endif; ?>>
                                        Cancelled</option>
                                   <option value="Paid" <?php if($orderDetails->order_status== "Paid"): ?> selected <?php endif; ?>>
                                           Paid</option>
                                </select>
                            </td>
                            <td>
                                <input type="submit" value="Update Status" class="btn btn-sm btn-success">
                            </td>
                        </tr>

                    </table>

                </form>
                </div>
             </div>
             <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                   <div class="btn-group" id="buttonexport">
                      <a href="#">
                         <h4>Shipping Address</h4>
                      </a>
                   </div>
                </div>
                <div class="panel-body">
                <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   
                   <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                   <div class="table-responsive">
                      <table id="table_id" class="table table-bordered table-striped table-hover">
                        
                         <tbody>
                           <tr>
                               <td class="taskDesc"> Name</td>
                               <td class="taskStatus"> <?php echo e($orderDetails->name); ?></td>
                           </tr>
                           <tr>
                            <td class="taskDesc"> Address</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->address); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> City</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->city); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> State</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->state); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Country</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->country); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Country Code</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->pincode); ?></td>
                        </tr>
                        <tr>
                            <td class="taskDesc"> Mobile</td>
                            <td class="taskStatus"> <?php echo e($orderDetails->mobile); ?></td>
                        </tr>
                        
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <section>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                       <div class="btn-group" id="buttonexport">
                          <a href="#">
                             <h4>Ordered Products</h4>
                          </a>
                       </div>
                    </div>
                    <div class="panel-body">
                    <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                       
                       <!-- Plugin content:powerpoint,txt,pdf,png,word,xl -->
                       <div class="table-responsive">
                          <table id="table_id" class="table table-bordered table-striped table-hover">
                            <thead>
                                <th>Product Code</th>
                                <th>Product Name</th>
                                <th>Product Size</th>
                                <th>Product Color</th>
                                <th>Product Price</th>
                                <th>Product Qty</th>
                            </thead>
                             <tbody>
                                <?php $__currentLoopData = $orderDetails->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($pro->product_code); ?></td>
                                    <td><?php echo e($pro->product_name); ?></td>
                                    <td><?php echo e($pro->product_size); ?></td>
                                    <td><?php echo e($pro->product_color); ?></td>
                                    <td><?php echo e($pro->product_price); ?></td>
                                    <td><?php echo e($pro->product_qty); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                          </table>
                       </div>
                    </div>
                 </div>
            </div>

        </div>
    </section>
    <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Way-Shop\resources\views/admin/orders/order_details.blade.php ENDPATH**/ ?>